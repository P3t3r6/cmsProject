cmsProject
==========

To do list!
----------
-Check if config has been done (Temporary index.php file/New file creation on config)