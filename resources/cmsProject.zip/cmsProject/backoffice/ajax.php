<?php include '../core/init.php'; include '../templates/getTop.php'; ?>

<script type="text/javascript">
function loadCont(){
	alert("alert");
	
	/*
	$.get("test.php", ({limit : 2}), function(data) {
	  $("#result").append($(data).select('.article'));
	}); */
	
	var menuId = $(".article");
	var article = $(data).select('.article');
	var request = $.ajax({
	  url: "test.php",
	  type: "POST",
	  async: false,
	  data: {id : menuId},
	  dataType: "html"
	});
	
	request.done(function( data ) {
	  $( "#result" ).html( data );
	});
}

$(window).scroll(function(){
	if  ($(window).scrollTop() == $(document).height() - $(window).height()){
		//alert("bot");
	}
}); 
</script>

<div id="result"></div>

<button onClick="loadCont()">load</button>

<?php include '../templates/getBot.php'; ?> 