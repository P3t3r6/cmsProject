<?php
	include '../core/init.php';
	include '../templates/getTop.php';
	
	if (isset($_GET['sendMail'])){
		$to = "cmsProject@localhost";
		$subject = "Hi!";
		$body = "test";
		$headers = "From: root@localhost"; 

		if ( mail($to, $subject, $body, $headers) ){
			echo("Message successfully sent!");
		} else {
			echo("Message delivery failed...");
		}
	}
?>

<form method="GET"><button name="sendMail">Send</button></form>

<?php include '../templates/getBot.php'; ?> 