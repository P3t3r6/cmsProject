<?php include '../core/init.php';
homepage(); ?>