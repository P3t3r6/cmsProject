<?php
$connect_error = 'An error as ocurred. <a href="../dbConfig.php">Have you configured everything correctly?</a>';
//error_reporting();

$dbHost = 'localhost';
$dbUser = 'root';
$dbPass = '';
$dbName = 'cmsProject';

mysql_connect($dbHost, $dbUser, $dbPass) or die($connect_error);
mysql_select_db($dbName) or die($connect_error);
?>
