<?php include '../core/init.php';
include $templatePath . '/includes/head.php';?>

<center>
	<span id="logo">
		<?php include $templatePath . 'includes/logo.php'?>
	</span>

	<br /><br /><br /><br />
	<span style="font-size:20pt;">Four, Oh, Four! &nbsp; &nbsp; :(</span>
	<br /><br />
	<span style="font-size:25pt;">There's nothing to see here!!!</span>
	<br />
	<span>Seriously ... There really isn't ...</span>
	<br /><br />
	<span><a href="../"><button>Take me home now</button></a></span>
</center>

<?php include '../templates/getBot.php'; ?>