<?php include '../core/init.php';
	  include '../templates/getTop.php';?>

      <h1 class="pageTitle">Article Archive</h1>

<?php archive(); ?>
<?php include '../templates/getBot.php'; ?>