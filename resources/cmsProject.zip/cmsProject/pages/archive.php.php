<?php include '../core/init.php';
include '../templates/getTop.php'; ?>

<h1 class="pageTitle">archive.php</h1>

<?php tagPage('archive.php'); ?>

<?php include '../templates/getBot.php'; ?>