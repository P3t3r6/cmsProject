<?php
include '../core/init.php';
protectPage();

if (empty($_POST) === false) {
	$required = array('currentPassword', 'password', 'repeatPassword');
	foreach($_POST as $key=>$value) {
		if (empty($value) && in_array($key, $required) === true) {
			$errors[] = 'Please fill the required fields.';
			break 1;
		}
	}
	
	if (md5($_POST['currentPassword']) === $userData['password']) {
		if (trim($_POST['password']) !== trim($_POST['repeatPassword'])) {
			$errors[] = 'The new passwords do not match';
		} else if (strlen($_POST['password']) < 6) {
			$errors[] = 'Your password must be at least 6 characters long.';
		}
	} else {
		$errors[] = 'The current password is incorrect';
	}
	
	if (!$errors){
		global $userData;
		mysql_query('UPDATE users SET password = \'' . md5($_POST['password']) . '\' WHERE id = ' . $userData['id']);
		$msgs[] = 'Saved!';
	}
}

include '../templates/getTop.php';
?>

<h1 class="pageTitle">Change Password</h1>

<form action="" method="POST">
	<input name="currentPassword" type="text" placeholder="Current Password" required/>
	<br />
	<input name="password" type="text" placeholder="New Password" required/>
	<br />
	<input name="repeatPassword" type="text" placeholder="Repeat New Password" required/>
	<br />
	<button type="submit" value="Submit" style="width:210px; margin:2px;">Submit</button>
</form>
<br />
<span style="color:#c33;"><?php outputErrors($errors); ?></span>
<span style="color:#3b4;"><?php outputMessages($msgs); ?></span>

<?php include '../templates/getBot.php'; ?>