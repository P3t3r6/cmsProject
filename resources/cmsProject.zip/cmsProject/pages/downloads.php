<?php include '../core/init.php';
include '../templates/getTop.php'; ?>

<h1 class="pageTitle">Downloads</h1>

<br />
<a href="../resources/cmsProject.zip"> Latest Version (17 Mar)</a>

<?php tagPage('downloads'); ?>

<?php include '../templates/getBot.php'; ?>