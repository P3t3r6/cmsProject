<?php include '../core/init.php';
	  include '../templates/getTop.php';?>

<h1 class="pageTitle">Welcome to the cmsProject</h1>

<?php homepage(); ?>

<?php include '../templates/getBot.php'; ?>