<?php include '../core/init.php';
include '../templates/getTop.php'; ?>

<script type="text/javascript">
	$(window).load(function(){
		$('#loading').fadeOut(2000);
	});
</script>

<div id="loading"></div>

<h1 class="pageTitle">Archive</h1>

<?php archive(); ?>

<?php include '../templates/getBot.php'; ?>