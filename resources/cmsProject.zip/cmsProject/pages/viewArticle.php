<?php include '../core/init.php';
	  include '../templates/getTop.php';
	  viewArticle();
	  if (isset($_POST['newComment'])){
		 newComment();
	  }
	  ?>
	  
	<div class="article" style="width:100%;">
		<h1 class="articleTitle"><?php echo htmlspecialchars( $results['article']->title )?></h1>
		<div style="background:rgba(255,255,255,0.03); padding:1px 15px; overflow:auto;"><?php echo $results['article']->content?></div>
		<p class="pubDate">Published on <?php echo date('j F Y', $results['article']->publicationDate)?></p>
	
		<h5 class="articleTitle">Comments</h5>
	<?php if (loggedIn()){ ?>
		<form method="POST">
			<input type="hidden" name="action" value="viewArticle"/>
			<input type="hidden" name="articleId" value="<?= $results['article']->id ?>"/>
			<img src="<?= userImage()?>" style="margin:10px 0px -18px 20px; height:45px; width:45px; border-radius:3px;" /> &nbsp;
			<input type="text" name="comment" style="width:30%; max-width:90%;"></textarea>
			<button type="submit" name="newComment" style="margin:0px;">Submit</button>
		</form>
		<br />
	<?php } ?>
		<?php showComments(); ?>
	</div>
	
<?php include '../templates/getBot.php'; ?>