// If this file exists in theme directory, it will be loaded in <head> section

new Image().src = 'themes/dark/img/loading.gif';
