# Contributing

I love pull-requests. However, this repo is just a mirror of [redactor-js official website](http://redactorjs.com/) hosted here for your, my dear GitHubbers, convenience.

Thus, no pull-requests will be accepted.

Issues on the other hand are a great tool to make the project authors aware of certain bugs or feature requests!

Happy coding!