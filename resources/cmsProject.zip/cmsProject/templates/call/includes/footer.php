<td id="footerBar" style="text-align:right; background:#fff; color:#777; padding:15px; border-radius:0px 0px 8px 8px; border-top: 1px dashed #aaa;">

<center>
<a href="">Mapa do site</a>
<a href="">Termos e condicoes</a>
<a href="">Contactos</a>
</center>

&copy; Pedro Realinho 2013

</td>