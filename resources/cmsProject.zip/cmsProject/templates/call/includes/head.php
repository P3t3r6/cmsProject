 <head>
 
	<title>cmsProject</title>
	
	<link rel="stylesheet" type="text/css" href="../templates/<?php echo $activeTemplate['name'] ?>/css/style.css"/>
	
	<link href="../images/favicon.ico" rel="shortcut icon" type="image/x-icon"/>
	
 </head>