	<table width="100%" cellspacing="0px" cellpadding="0px">
	
		<tr height="190px" style="vertical-align:bottom;">
			<td width="40px">
			
			</td>
			
			<?php include "../templates/" . $activeTemplate['name'] . "/includes/logo.php";?>
			
			<td width="40px">
			
			</td>
		</tr>
		
		<tr height="55px" style="vertical-align:center;">
		
			<td width="40px" style="background:#ddd;">

			</td>
			
			<td name="menu" style="background:#ddd;">
			
				<nav id="menu" style="position:relative; margin-left:10px; top:20px; float:left; width:100%;">

				<?php include "../templates/" . $activeTemplate['name'] . "/includes/menu.php"; ?>
				
				</nav>
				
				<div style="position:relative; float:right; position:relative; top:-9px;">
				 <input type="text" id="search" style="margin-right:20px;"></input>
				</div>
				
			</td>
			
			<td width="40px" style="background:#ddd;">
			
			</td>
		</tr>
		
		<tr height="20px">
			<td width="40px">
			
				 <div style="width: 0px;
						 height: 0px;
						 border-style: solid;
						 border-width: 0 40px 20px 0;
						 border-color: transparent #bbb transparent transparent;">
				 </div>
			
			</td>
			
			<td style="background:#fff;">
			
				<div style="height:20px; width:100%; box-shadow: inset 0px 5px 15px rgba(0,0,0,0.1);"></div>
			
			</td>

			 <td width="40px">
			
				 <div style="width: 0px;
						 height: 0px;
						 border-style: solid;
						 border-width: 20px 40px 0 0;
						 border-color: #bbb transparent transparent transparent;">
				</div>
			
			</td>
		</tr>
		
		<tr height="" style="vertical-align:top;">
			<td width="40px">
			
			</td>