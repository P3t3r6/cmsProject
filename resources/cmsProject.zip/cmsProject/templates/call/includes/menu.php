<ul width="100%">

	<li><a class="menuItem" href="index.php">Home</a></li>
	
	<li><a class="menuItem" href="">menu item 1</a></li>
	
	<li><a class="menuItem" href="">menu item 2</a></li>

	<li><a class="menuItem" href="">menu item 3</a>
		<ul>
			<a href="#"><li>sub item 1</li></a>
			<a href="#"><li>sub item 2</li></a>
			<a href="#"><li>sub item 3</li></a>
		</ul>
	</li>
</ul>