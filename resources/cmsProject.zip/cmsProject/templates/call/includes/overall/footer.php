
				</div></td>
				
				<td style="width:1px; background:rgba(0,0,0,0.3);">
				<!-- vertical div -->
				</td>
				
				<?php include "../templates/" . $activeTemplate['name'] . "/includes/sidebar.php"; ?>
				
				</tr>
				</table>
				</td>
				
			<td width="40px">

			</td>
		</tr>
		
		<tr height="50px">
		
			<td width="40px">

			</td>
			
				<?php include "../templates/" . $activeTemplate['name'] . "/includes/footer.php"?>
							
			<td width="40px">

			</td>
		</tr>
		
	</table>
		</div>
	
	<a href="#pageTop" class="defaultBtn" style="padding:8px; border-radius:5px; position:fixed; bottom:35px; right:50px; color:#fff;">
		Go to Top
	</a>
	
	<a id="pageBottom"/> 
 </body>
</html>