
				</div></td>
				
				</tr>
				</table>
				</td>
				
			<td width="40px">

			</td>
		</tr>
		
		<tr height="50px">
		
			<td width="40px">

			</td>
			
				<?php include "../templates/" . $activeTemplate['name'] . "/includes/footer.php"?>
							
			<td width="40px">

			</td>
		</tr>
		
	</table>
		</div>
	
	<a href="#pageTop" class="defaultBtn" style="padding:10px; border-radius:5px; position:fixed; bottom:35px; right:50px;">
		Go to Top
	</a>
	
	<a id="pageBottom"/>
 </body>
</html>