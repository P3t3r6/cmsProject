<html>

<?php include "../templates/" . $activeTemplate['name'] . "/includes/head.php"; ?>

 <body>

	<a id="pageTop"/>

		<div id="mainDiv">
		
		<?php include "../templates/" . $activeTemplate['name'] . "/includes/header.php"; ?>
					
			<td style="background:#fff; padding:10px;">
			 <table style="height:100%; width:100%; margin:0px; padding:0px;" border="0px">
			 <tr>
			 
				<td style="vertical-align:top;"><div style="height:100%; width:100%; padding:0px; margin:0px;">
