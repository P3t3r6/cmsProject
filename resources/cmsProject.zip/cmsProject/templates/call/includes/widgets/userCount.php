<div style="width:245px; padding:3px; margin: 20px 0px;">

	<h3 class="widgetTitle"> Users </h3>
	There are currently:
	<ul style="margin:0px;">
		<li><?php echo userCount(); ?> registred users</li>
		<!--
		<li>x online users</li>
		<li>x active users</li>
		-->
	</ul>

</div>