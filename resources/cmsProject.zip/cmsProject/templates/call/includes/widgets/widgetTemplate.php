<div style="width:245px; padding:3px; margin: 20px 0px;">

	<h3 class="widgetTitle"> widget title </h3>
	Text

</div>