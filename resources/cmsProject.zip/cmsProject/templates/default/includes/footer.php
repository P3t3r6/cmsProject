<ul>
	<li>Site Map
	<ol>
		<li><a href="index.php">Home</a></li>
		<li><a href="../pages/archive.php">Archive</a></li>
		<li><a href="../pages/downloads.php">Downloads</a></li>
		<li>Docs</li>
	</ol>
	</li>
	<li>About us
	<ol>
		<li><a href="../pages/Company.php">Company</a></li>
		<li><a href="../pages/The%20Team.php">The Team</a></li>
		<li>Projects</li>
	</ol>
	</li>
	<li>Reach us
	<ol>
		<li><a href="../pages/Bug%20Report.php">Found a bug? Report it!</a></li>
		<li>Work with the team</li>
		<li>Show us your work</li>
		<li>Get involved</li>
		<li>Get a Job!</li>
	</ol>
	</li>
</ul>
