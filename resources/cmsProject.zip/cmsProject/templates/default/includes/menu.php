<ul>
	<a href="index.php"><li>Home</li></a>
	<a href="../pages/archive.php"><li>Archive</li></a>
	<a href="../pages/downloads.php"><li>Downloads</li></a>
	<li>Docs
	<ol>
		<li>Tutorials</li>
		<li>Manual and guide</li>
		<li>API</li>
	</ol>
	</li>
	<li>About</li>
	<li>Contacts</li>
</ul>