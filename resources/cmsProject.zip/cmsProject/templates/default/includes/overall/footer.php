			<!-- end of page display -->
		</div>
	
		<div id="footer">
			<div id="footerMenu">
				<?php include $templatePath . 'includes/footer.php'?>
			</div>
		</div>
	</div>
	<script type="text/javascript">
		updateFooter();
	</script>
</body>
<html>