<!DOCTYPE html>

<?php include $templatePath . 'includes/head.php'?>

<body>
	<input id="loginMenuHidder" type="checkbox" />
	
	<div id="loginMenu">	
		<label id="lmhButton" for="loginMenuHidder" onClick="stickyFooter()">&equiv;
			<span id="lmhName">
				<?php
					if (loggedIn() === true){
						echo $userData['username'];
					} else {
						echo 'Hi Guest!';
					}
				?>		
			</span>
		</label>
		
		<script type="text/javascript">
			function stickyFooter(){
				//alert('s1. loginMenu ' + $('#loginMenu').css('left') + '  footer ' + $('#footer').css('left'));
				
				if ($('#loginMenu').css('-webkit-transform') === 'translate(0px,0px)'){
					$('#footer').css('-webkit-transform', 'translate(0px,0px)');
					setTimeout(function(){ $('body').css('overflow-x', 'auto'); },500);
				}
				
				if ($('#loginMenu').css('-webkit-transform') === 'translate(-250px,0px)'){
					$('#footer').css('-webkit-transform', 'translate(250px,0px)');
					$('body').css('overflow-x', 'hidden');
				}
				
				//alert('2. loginMenu ' + $('#loginMenu').css('left') + '  footer ' + $('#footer').css('left'));
			}
			
			function updateFooter(){
				//alert('u1. loginMenu ' + $('#loginMenu').css('left') + '  footer ' + $('#footer').css('left'));
				
				if ($('#loginMenu').css('-webkit-transform') === 'translate(-250px,0px)'){
					$('#footer').css('-webkit-transform', 'translate(0px,0px)');
					setTimeout(function(){ $('body').css('overflow-x', 'auto'); },500);
				}
				
				if ($('#loginMenu').css('-webkit-transform') === 'translate(0px,0px)'){
					$('#footer').css('-webkit-transform', 'translate(250px,0px)');
					$('body').css('overflow-x', 'hidden');
				}
				
				//alert('2. loginMenu ' + $('#loginMenu').css('left') + '  footer ' + $('#footer').css('left'));
			}
			
			$(window).scroll(function(){
				if ($(this).scrollTop() > 120) {
					$('#lmhName').css('opacity', 0);
					$('#lmhName').css('left', 20);
					$('#lmhName').css('visibility', 'hidden');
				} else {
					$('#lmhName').css('opacity', 100);
					$('#lmhName').css('left', 31);
					$('#lmhName').css('visibility', 'visible');
				}
			});
		</script>
		
		<br />
		
		<?php
		if (loggedIn() === false){
			if (isset($_POST['sidelogin'])){
				loginPage();
				?>
				<script type="text/javascript">
					$('#loginMenuHidder').prop('checked', true);
				</script>				
				<?php } ?>
				
			<form method="POST" style="margin: 15px auto;">
				<h1 class="articleTitle">Login</h1>
				<input type="text" name="username" placeholder="User" style="width:140px;" required/><br />
				<input type="password" name="password" placeholder="Password" style="width:140px;" required/><br />
				<button type="submit" name="sidelogin" style="padding:10px 0px; width:200px;">Login</button>
				<p style="font-size:10pt; color:#c33;"><?php if (isset($_POST['sidelogin'])){outputErrors($errors);} ?></p>
			</form>
			
			<br />
			
			<form method="POST" style="margin: 15px auto;">
				<h1 class="articleTitle">Register</h1>
				<input type="text" name="username" placeholder="User" style="width:140px;" required/><br />
				<input type="password" name="password" placeholder="Password" style="width:140px;" required/><br />
				<input type="text" name="email" placeholder="Email" style="width:140px;" required/><br />
				<button type="submit" name="sidelogin" style="padding:10px 0px; width:200px;">Submit</button>
				<p style="font-size:10pt; color:#c33;"><?php if (isset($_POST['sidelogin'])){outputErrors($errors);} ?></p>
			</form>
		
		<?php } else {
			?>
				<center>
					<?= $userData['username'] ?>
					<br />
					<?php
						echo ($userData['level'] == 1 ? 'God' : '');
						echo ($userData['level'] == 2 ? 'Admin' : '');
						echo ($userData['level'] == 3 ? 'Mod' : '');
					?>
					<br />
					<br />
					<img src="<?= userImage(); ?>" style="width:100%; border-radius:3px; box-shadow:0px 5px 20px rgba(0,0,0,0.5);" />
				</center>
			<?php
			if ($userData['level'] <= 2){
				echo '<br /><a href="../backoffice"><button style="width:100%;">Backoffice</button></a>';
			}
			echo '<br /><a href="../pages/profile.php"><button style="width:100%;">Profile</button></a>';
			echo '<br /><a href="?logout=logout"><button style="width:100%;">Logout</button></a>';
		} ?>
	</div>
	
	<div id="mainDiv">
	
		<div id="logo">
			<?php include $templatePath . 'includes/logo.php'?>
		</div>
		
		<nav id="navMenu">
		 <ol id="menu">
		 	<?php include $templatePath . 'includes/menu.php'?>
		 </ol>
		</nav>
		
		<div id="pages">
			<!-- page display -->