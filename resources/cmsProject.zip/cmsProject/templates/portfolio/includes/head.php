<head>
	
	<title>cmsProject</title>

	<link rel="stylesheet" type="text/css" href="../templates/<?php echo $activeTemplate['name'] ?>/css/style.css"/>
	<link href="../images/favicon.ico?" rel="shortcut icon" type="image/x-icon"/>

	<script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js?ver=1.7.0'></script>
	<!-- <script src="../plugins/masonry.pkgd.min.js"></script> -->
</head>