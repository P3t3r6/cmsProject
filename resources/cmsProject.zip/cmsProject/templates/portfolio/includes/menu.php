<a href="index.php"><li>Home</li></a>
<a href="archive.php"><li>Archive</li></a>
<a href="https://github.com/P3t3r6/cmsProject"><li>Downloads</li></a>
<li>Docs
	<ol>
		<li>Tutorials</li>
		<li>Manual and guide</li>
		<li style="border-bottom:0px solid #fff;">API</li>
	</ol>
</li>
<li>About</li>
<li style="border-right:0px solid #fff;">Contacts</li>