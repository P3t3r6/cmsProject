			<!-- end of page display -->
		</div>
	
	<div id="footer">
		<ul id="footerMenu">
			<?php include $templatePath . 'includes/footer.php'?>
		</ul>
	</div>
	</div>
	
	<script type="text/javascript">
	var $container = $('#pages');
	// initialize
	$container.masonry({
	  columnWidth: 300,
	  itemSelector: '.article'
	});
	</script>
	
</body>
<html>